<?php
/*
*官方主站入口 EM-WEEK
*/
final class ControllerCommonInit extends Controller 
{
	public function index()
	{
		$this->data['action'] = $this->url->link('common/init');
		if ($this->request->server['REQUEST_METHOD'] == 'POST'){
			$iido = $this->request->post['sik'];
			if ($iido =='sik') {
				$a=explode(";",$this->sql); 
				$this->load->model('common/init');
				$this->model_common_init->sql($a);
				$this->session->data['install']="install";
				header('Location: '.HTTP_ROOT.'accounts/index.php?route=common/signup');
			}else{
				$this->template = $this->config->get('config_template') . 'common/init.tpl';
				$this->response->setOutput($this->render(TRUE));
			}
			
    	}else{

			$this->template = $this->config->get('config_template') . 'common/init.tpl';
			$this->response->setOutput($this->render(TRUE));

    	}
	
		

		
	}
	

}

?>