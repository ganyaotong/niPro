<?php

// HTTP
define('HTTP_SERVER', 'http://'.$_SERVER['HTTP_HOST'].'/install/');
define('HTTP_IMAGE',  'http://'.$_SERVER['HTTP_HOST'].'/image/');
define('HTTP_ADMIN',  'http://'.$_SERVER['HTTP_HOST'].'/admin/');
define('HTTP_ROOT',   'http://'.$_SERVER['HTTP_HOST'].'/');

// HTTPS
define('HTTPS_ROOT',   'https://'.$_SERVER['HTTP_HOST'].'/');
define('HTTPS_SERVER', 'https://'.$_SERVER['HTTP_HOST'].'/');
define('HTTPS_IMAGE',  'https://'.$_SERVER['HTTP_HOST'].'/image/');

// 数据库配置
define('DB_DRIVER',   'mysql');                            // 数据库类型，暂时支持mysql和mssql
define('DB_HOSTNAME', "127.0.0.1:3306");// 主机
define('DB_USERNAME', "root");					   // 数据库用户名
define('DB_PASSWORD', "root");					   // 数据库密码
define('DB_DATABASE', "sik");					   // 数据库名
define('DB_PREFIX',   '');				        		   // 数据库表名前缀

//SAE硬盘
/*
define('SAE_DOMAIN', "upload");                            //未完全使用。所以，必须使用upload这个domain
define('SAE_STOR_URL', "http://".$_SERVER['HTTP_APPNAME']."-".SAE_DOMAIN.".stor.sinaapp.com");
                                                           //stor下载url
define('SAE_STOR', "saestor://".SAE_DOMAIN."/");           //SAE提供的Wrappers，即 saestor://upload/
*/

// 全局目录配置
define('DIR_ROOT', str_replace('\install', '', dirname(__FILE__)));     // 主机根目录
define('DIR_APPLICATION', 	DIR_ROOT . '/install/');				    // 前台目录
define('DIR_SYSTEM', 		DIR_ROOT . '/system/');				        // 框架目录
define('DIR_TEMPLATE', 		DIR_ROOT . '/install/view/template/');      // 模板目录
define('DIR_CONFIG', 		DIR_ROOT . '/system/config/');			    // 配置目录
define('DIR_DATABASE', 		DIR_ROOT . '/system/database/');		    // 数据库驱动目录
define('DIR_LOGS', 			DIR_ROOT . '/system/logs/');			    // 日志目录
define('DIR_CACHE', 		DIR_ROOT . '/system/cache/');		        // 缓存目录
define('DIR_LANGUAGE',      DIR_ROOT . '/install/language/');           // 语言目录
define('DIR_IMAGE',         '/image/');                                 // 图片目录
define('DIR_DOWNLOAD',      DIR_ROOT . '/download/');                   // 下载目录

// addon 模板
define('TEMPLATE_WEISITE',   'basis/weisite/action/');		                    // 微网站根目录
define('ASSETS_WEISITE',   '/install/view/template/basis/weisite/action/');		// 微网站根目录

?>